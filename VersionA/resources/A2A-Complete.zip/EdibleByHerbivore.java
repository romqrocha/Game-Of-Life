public interface EdibleByHerbivore {}
