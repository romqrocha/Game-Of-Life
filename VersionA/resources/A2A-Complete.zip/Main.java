public class Main {

    /**
     * Entry point of the game.
     * @param args Unused.
     */
    public static void main(String[] args) {
        createGame();
    }

    /** Creates a Game object. */
    private static void createGame() {
        new Game();
    }
}
